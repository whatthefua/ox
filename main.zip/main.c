#include <stdio.h>

typedef struct
{
    int macroBoard[3][3];
    int board[3][3][3][3];

    int timeBank, timePerMove;
    char playerNames[2][10];
    char name[10];
    int id, round, move, time;
} gameinfo;

typedef struct
{
    int moveId;
    float eval;
} mmReturn;

gameinfo info;

char str[200];
float coef[] = {20.478637,9.423002,-2.380617,5.759347,2.644377,-0.405372,2.000290,1.863064,0.848238,2.645214,1.729981,1.549901,2.464689,1.796885,1.260213,61.134758,-8.106978,0.465631,0.519616,2.016239,1.165947,2.083807,0.849423,1.315592,1.369957,0.553462,1.304882,3.049581,1.204632,1.166322};

void getTimeBank();
void getTimePerMove();
void getPlayerNames();
void getName();
void getId();

void updateMove();
void updateRound();
void updateMacroBoard();
void updateBoard();
void actionRequest();
void showStatus();
float boardEvalRow(int[3][3]);
float boardEvalRowDraw(int[3][3]);
float boardEvalCell(int[3][3]);
float eval(gameinfo);
gameinfo place(gameinfo, int, int, int, int, int);
mmReturn minimax(gameinfo, int, int);
void play(int t);

void getTimeBank()
{
    int err;
    err = scanf("%d",&info.timeBank);
}

void getTimePerMove()
{
    int err;
    err = scanf("%d",&info.timePerMove);
}

void getPlayerNames()
{
    int err;
    err = scanf("%s%s",info.playerNames[0], info.playerNames[1]);
}

void getName()
{
    int err;
    err = scanf("%s",info.name);
}

void getId()
{
    int err;
    err = scanf("%d",&info.id);
}

void updateRound()
{
    int err;
    err = scanf("%d",&info.round);
}

void updateMove()
{
    int err;
    err = scanf("%d",&info.move);
}

void updateMacroBoard()
{
    int i, j;
    int c = 0;
    int err;

    err = scanf("%s",str);

    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            if(str[c] == '-')
            {
                info.macroBoard[i][j] = -1;
                c += 3;
            } else {
                info.macroBoard[i][j] = (int)(str[c] - '0');
                c += 2;
            }
        }
    }
}

void updateBoard()
{
    int i, j, k, l, c = 0;
    int err;

    err = scanf("%s",str);

    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            for(k = 0; k < 3; k++)
            {
                for(l = 0; l < 3; l++)
                {
                    info.board[i][k][j][l] = (int)(str[c] - '0');
                    c += 2;
                }
            }
        }
    }
}

void actionRequest()
{
    int err;
    err = scanf("%d",&info.time);
    play(info.time);
}

void showStatus(gameinfo board)
{
    int i, j, k, l;

    printf("Macroboard\n");

    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            printf("%d ",board.macroBoard[i][j]);
        }

        printf("\n");
    }

    printf("board\n");

    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            for(k = 0; k < 3; k++)
            {
                for(l = 0; l < 3; l++)
                {
                    printf("%d ",board.board[i][k][j][l]);
                }
            }

            printf("\n");
        }
    }
}

float boardEvalRow(int board[3][3])
{
    float res = (float)0;
    int i;

    for(i = 0; i < 3; i++)
    {
        if(board[i][0] == board[i][1] && board[i][1] == board[i][2])
        {
            if(board[i][0] == info.id)
            {
                return (float)1;
            } else if(board[i][0] == (info.id ^ 3)) {
                return (float)-1;
            }
        }

        if(board[0][i] == board[1][i] && board[1][i] == board[2][i])
        {
            if(board[0][i] == info.id)
            {
                return (float)1;
            } else if(board[0][i] == (info.id ^ 3)) {
                return (float)-1;
            }
        }
    }

    if(board[0][0] == board[1][1] && board[1][1] == board[2][2])
    {
        if(board[0][0] == info.id)
        {
            return (float)1;
        } else if(board[0][0] == (info.id ^ 3)) {
            return (float)-1;
        }
    }

    if(board[2][0] == board[1][1] && board[1][1] == board[0][2])
    {
        if(board[2][0] == info.id)
        {
            return (float)1;
        } else if(board[2][0] == (info.id ^ 3)) {
            return (float)-1;
        }
    }

    return res;
}

float boardEvalRowDraw(int board[3][3])
{
    float res = (float)0;
    int i, j;

    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            if(board[i][j] <= 0)
            {
                board[i][j] = info.id;

                if(board[i][0] == board[i][1] && board[i][1] == board[i][2])
                {
                    res += (float)1;
                } else if(board[0][j] == board[1][j] && board[1][j] == board[2][j]) {
                    res += (float)1;
                } else if(i == j && board[0][0] == board[1][1] && board[1][1] == board[2][2]) {
                    res += (float)1;
                } else if(2 - i == j && board[2][0] == board[1][1] && board[1][1] == board[0][2]) {
                    res += (float)1;
                }

                board[i][j] ^= 3;

                if(board[i][0] == board[i][1] && board[i][1] == board[i][2])
                {
                    res -= (float)1;
                } else if(board[0][j] == board[1][j] && board[1][j] == board[2][j]) {
                    res -= (float)1;
                } else if(i == j && board[0][0] == board[1][1] && board[1][1] == board[2][2]) {
                    res -= (float)1;
                } else if(2 - i == j && board[2][0] == board[1][1] && board[1][1] == board[0][2]) {
                    res -= (float)1;
                }

                board[i][j] = 0;
            }
        }
    }

    return res;
}

float boardEvalCell(int board[3][3])
{
    float res = (float)0;
    int i, j;

    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            if(board[i][j] >= 0)
            {
                if(board[i][j] == info.id)
                {
                    res += (float)1;
                } else if(board[i][j] == (info.id ^ 3)) {
                    res -= (float)1;
                }
            }
        }
    }

    return res;
}

float eval(gameinfo board)
{
    int i, j, k, l;
    float score = (float)0;

    /*for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            if(board.macroBoard[i][j] == info.id)
            {
                score += coef[i * 3 + j];
            } else if(board.macroBoard[i][j] == (info.id ^ 3)) {
                score += coef[i * 3 + j + 9];
            }
        }
    }

    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            for(k = 0; k < 3; k++)
            {
                for(l = 0; l < 3; l++)
                {
                    if(board.board[i][k][j][l] == info.id)
                    {
                        score += coef[i * 27 + j * 9 + k * 3 + l + 18];
                    } else {
                        score += coef[i * 27 + j * 9 + k * 3 + l + 99];
                    }
                }
            }
        }
    }*/

    score += boardEvalRow(board.macroBoard) * coef[0] + boardEvalRowDraw(board.macroBoard) * coef[1] + boardEvalCell(board.macroBoard) * coef[2];

    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            score += boardEvalRow(board.board[i][j]) * coef[i * 9 + j * 3 + 3] + boardEvalRowDraw(board.board[i][j]) * coef[i * 9 + j * 3 + 4] + boardEvalCell(board.board[i][j]) * coef[i * 9 + j * 3 + 5];
        }
    }

    return score;
}

gameinfo place(gameinfo board, int x1, int y1, int x2, int y2, int p)
{
    int i, j;

    board.board[x1][y1][x2][y2] = p;

    if(board.board[x1][y1][x2][0] == board.board[x1][y1][x2][1] && board.board[x1][y1][x2][1] == board.board[x1][y1][x2][2])
    {
        board.macroBoard[x1][y1] = p;
    } else if(board.board[x1][y1][0][y2] == board.board[x1][y1][1][y2] && board.board[x1][y1][1][y2] == board.board[x1][y1][2][y2]) {
        board.macroBoard[x1][y1] = p;
    } else if(x2 == y2 && board.board[x1][y1][0][0] == board.board[x1][y1][1][1] && board.board[x1][y1][1][1] == board.board[x1][y1][2][2]) {
        board.macroBoard[x1][y1] = p;
    } else if(2 - x2 == y2 && board.board[x1][y1][2][0] == board.board[x1][y1][1][1] && board.board[x1][y1][1][1] == board.board[x1][y1][0][2]) {
        board.macroBoard[x1][y1] = p;
    }

    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            if(board.macroBoard[i][j] == -1)
            {
                board.macroBoard[i][j] = 0;
            }
        }
    }

    if(board.macroBoard[x2][y2] == 0)
    {
        board.macroBoard[x2][y2] = -1;
    } else {
        for(i = 0; i < 3; i++)
        {
            for(j = 0; j < 3; j++)
            {
                if(board.macroBoard[i][j] == 0)
                {
                    board.macroBoard[i][j] = -1;
                }
            }
        }
    }

    return board;
}

int end(gameinfo board)
{
    int i;

    for(i = 0; i < 3; i++)
    {
        if(board.macroBoard[i][0] == board.macroBoard[i][1] && board.macroBoard[i][1] == board.macroBoard[i][2])
        {
            if(board.macroBoard[i][0] == info.id)
            {
                return 1000000;
            } else if(board.macroBoard[i][0] == (info.id ^ 3)) {
                return -1000000;
            }
        }

        if(board.macroBoard[0][i] == board.macroBoard[1][i] && board.macroBoard[1][i] == board.macroBoard[2][i])
        {
            if(board.macroBoard[0][i] == info.id)
            {
                return 1000000;
            } else if(board.macroBoard[0][i] == (info.id ^ 3)) {
                return -1000000;
            }
        }
    }

    if(board.macroBoard[0][0] == board.macroBoard[1][1] && board.macroBoard[1][1] == board.macroBoard[2][2])
    {
        if(board.macroBoard[0][0] == info.id)
        {
            return 1000000;
        } else if(board.macroBoard[0][0] == (info.id ^ 3)) {
            return -1000000;
        }
    }

    if(board.macroBoard[2][0] == board.macroBoard[1][1] && board.macroBoard[1][1] == board.macroBoard[0][2])
    {
        if(board.macroBoard[2][0] == info.id)
        {
            return 1000000;
        } else if(board.macroBoard[2][0] == (info.id ^ 3)) {
            return -1000000;
        }
    }

    return 0;
}

mmReturn minimax(gameinfo board, int rem_depth, int hero)
{
    int i, j, k, l;
    mmReturn res,tmp;
    gameinfo gtmp;

    i = end(board);

    if(i != 0)
    {
        res.eval = (float)i;
        return res;
    }

    if(rem_depth == 0)
    {
        res.eval = eval(board);
        return res;
    }

    if(hero == 1)
    {
        res.eval = (float)-1000000000;

        for(i = 0; i < 3; i++)
        {
            for(j = 0; j < 3; j++)
            {
                if(board.macroBoard[i][j] == -1)
                {
                    for(k = 0; k < 3; k++)
                    {
                        for(l = 0; l < 3; l++)
                        {
                            if(board.board[i][j][k][l] == 0)
                            {
                                gtmp = place(board, i, j, k, l, info.id);

                                tmp = minimax(gtmp, rem_depth - 1, 0);

                                if(tmp.eval > res.eval)
                                {
                                    res.eval = tmp.eval;
                                    res.moveId = (j * 3 + l) * 9 + i * 3 + k;
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        res.eval = (float)1000000000;

        for(i = 0; i < 3; i++)
        {
            for(j = 0; j < 3; j++)
            {
                if(board.macroBoard[i][j] == -1)
                {
                    for(k = 0; k < 3; k++)
                    {
                        for(l = 0; l < 3; l++)
                        {
                            if(board.board[i][j][k][l] == 0)
                            {
                                gtmp = place(board, i, j, k, l, info.id ^ 3);

                                tmp = minimax(gtmp, rem_depth - 1, 1);

                                if(tmp.eval < res.eval)
                                {
                                    res.eval = tmp.eval;
                                    res.moveId = (j * 3 + l) * 9 + i * 3 + k;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return res;
}

void play(int t)
{
    int i, j, k, l;
    mmReturn res;

    res = minimax(info, 5, 1);
    printf("place_move %d %d\n",res.moveId / 9, res.moveId % 9);
    fflush(stdout);
}

int main()
{
    int err;
    gameinfo tmp;

    while(1)
    {
        err = scanf("%s",str);

        if(*str == 's')
        {
            err = scanf("%s",str);

            if(*str == 't')
            {
                if(str[4] == 'b')
                {
                    getTimeBank();
                } else {
                    getTimePerMove();
                }
            } else if(*str == 'p') {
                getPlayerNames();
            } else if(*str == 'y') {
                if(str[8] == 'i')
                {
                    getId();
                } else {
                    getName();
                }
            }
        } else if(*str == 'u') {
            err = scanf("%s",str);
            err = scanf("%s",str);

            if(*str == 'm')
            {
                if(str[1] == 'a')
                {
                    updateMacroBoard();
                } else {
                    updateMove();
                }
            } else if(*str == 'f') {
                updateBoard();
            } else if(*str == 'r') {
                updateRound();
            }
        } else if(*str == 'a') {
            err = scanf("%s",str);

            actionRequest();
        } else if(*str == 'd') {
            showStatus(info);
            tmp = place(info, 0, 0, 0, 0, 1);
            showStatus(tmp);
        }

        //showStatus();
    }
}

/*
settings timebank 10000
settings time_per_move 500
settings player_names player1,player2
settings your_bot player1
settings your_botid 1
update game round 1
update game move 1
update game field 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
update game macroboard -1,-1,-1,-1,-1,-1,-1,-1,-1
action move 10000
*/
